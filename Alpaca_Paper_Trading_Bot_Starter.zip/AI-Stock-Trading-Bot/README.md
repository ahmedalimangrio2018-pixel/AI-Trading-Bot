# Alpaca US Stock Paper-Trading Bot (Starter)

This is an educational starter project for **Alpaca paper trading only**.

## Safety defaults
- Alpaca SDK client is created with `paper=True`.
- No live trading endpoint is configured.
- `ENABLE_PAPER_ORDERS` defaults to `false` (signal-only mode).
- Never commit API keys to GitHub.
- Use paper API keys only.

## Strategy
A basic 5-minute trend + breakout example:
- 9-period moving average above 21-period moving average.
- Latest completed 5-minute close breaks above the prior 12 completed bars' high.
- Stop reference below recent lows; target is 2R.
- Position sizing targets 0.5% of account equity at risk.
- Maximum 3 open positions and a 2% account daily-loss circuit breaker.

This is **not** an AI model, not the installed Day Trader Skill, and not a validated profitable strategy. It is a transparent rules-based prototype. It can lose money even in simulation and may behave differently due to slippage, gaps, data delays, and order execution.

## Deploy
1. Create a private GitHub repository.
2. Upload `bot.py`, `requirements.txt`, `render.yaml`, and this README.
3. In Render, create a Background Worker from the GitHub repository.
4. Add `ALPACA_API_KEY` and `ALPACA_SECRET_KEY` as secret environment variables using **paper** credentials.
5. Keep `ENABLE_PAPER_ORDERS=false` initially.
6. Deploy and inspect logs for data access and signal output.

Only after reviewing behavior over a meaningful paper-testing period should you consider enabling simulated orders by setting `ENABLE_PAPER_ORDERS=true`.

## Important limitations
- Uses Alpaca IEX feed; data entitlements and availability depend on your Alpaca account.
- The sample scans a small fixed watchlist, not every US-listed stock.
- No AI/LLM call is made by this program.
- No automatic news, earnings, halt, or corporate-action filter is included.
- Bracket orders may be rejected if prices or market conditions do not satisfy broker rules.
- The daily-loss check is a basic account-level guard, not a guaranteed hard stop.
- A running cloud worker incurs hosting costs. Review current pricing before deployment.
