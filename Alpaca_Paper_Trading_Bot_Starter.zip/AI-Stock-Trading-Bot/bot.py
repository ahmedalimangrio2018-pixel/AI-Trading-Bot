import os
import time
import logging
from datetime import datetime, timedelta, timezone

from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, TakeProfitRequest, StopLossRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderClass
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame

# PAPER ONLY: this client is deliberately hard-coded to Alpaca's paper environment.
KEY = os.environ["ALPACA_API_KEY"]
SECRET = os.environ["ALPACA_SECRET_KEY"]
ENABLE_ORDERS = os.getenv("ENABLE_PAPER_ORDERS", "false").lower() == "true"

trading = TradingClient(KEY, SECRET, paper=True)
market_data = StockHistoricalDataClient(KEY, SECRET)

# Starter watchlist only; expand after testing data access and strategy behavior.
SYMBOLS = os.getenv("SYMBOLS", "AAPL,MSFT,NVDA,AMZN,META,TSLA").split(",")
MAX_POSITIONS = int(os.getenv("MAX_POSITIONS", "3"))
RISK_FRACTION = float(os.getenv("RISK_FRACTION", "0.005"))  # 0.5%
DAILY_LOSS_LIMIT = float(os.getenv("DAILY_LOSS_LIMIT", "0.02"))  # 2%
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "300"))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)

def get_bars(symbol):
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=5)
    request = StockBarsRequest(
        symbol_or_symbols=symbol,
        timeframe=TimeFrame.Minute,
        start=start,
        end=end,
        limit=500,
        feed="iex",
    )
    df = market_data.get_stock_bars(request).df
    if df.empty:
        return None
    if getattr(df.index, "nlevels", 1) > 1:
        df = df.xs(symbol, level="symbol")
    return df.sort_index()

def find_signal(symbol):
    df = get_bars(symbol)
    if df is None or len(df) < 60:
        logging.info("%s: insufficient bars; skip", symbol)
        return None

    # Use completed 5-minute candles, derived from 1-minute bars.
    bars = df.resample("5min").agg({
        "open": "first", "high": "max", "low": "min",
        "close": "last", "volume": "sum"
    }).dropna()

    if len(bars) < 30:
        return None

    close = bars["close"]
    last = bars.iloc[-2]  # avoid using a potentially incomplete current candle
    history = bars.iloc[:-1]
    fast = close.rolling(9).mean().iloc[-2]
    slow = close.rolling(21).mean().iloc[-2]
    prior = history.iloc[-13:-1]
    if len(prior) < 12 or fast <= slow:
        return None

    breakout_level = prior["high"].max()
    price = float(last["close"])
    if price <= breakout_level:
        return None

    stop = float(min(last["low"], prior["low"].min()))
    risk_per_share = price - stop
    if risk_per_share <= 0 or risk_per_share / price > 0.02:
        return None

    target = price + 2 * risk_per_share
    return {"entry_reference": price, "stop": stop, "target": target}

def daily_loss_exceeded(account):
    equity = float(account.equity)
    last_equity = float(account.last_equity)
    if last_equity <= 0:
        return True
    # Account-level day P/L check. Conservative: stop if loss reaches configured limit.
    pnl_fraction = (equity - last_equity) / last_equity
    logging.info("Day P/L: %.2f%%", pnl_fraction * 100)
    return pnl_fraction <= -DAILY_LOSS_LIMIT

def main():
    logging.info("Starting Alpaca PAPER bot. Orders enabled=%s", ENABLE_ORDERS)
    logging.info("Paper mode is enforced in code; this bot has no live endpoint.")
    while True:
        try:
            clock = trading.get_clock()
            if not clock.is_open:
                logging.info("US market closed. Next open: %s", clock.next_open)
                time.sleep(POLL_SECONDS)
                continue

            account = trading.get_account()
            if daily_loss_exceeded(account):
                logging.error("Daily loss limit reached. No new orders.")
                time.sleep(POLL_SECONDS)
                continue

            positions = trading.get_all_positions()
            held = {p.symbol for p in positions}
            if len(positions) >= MAX_POSITIONS:
                logging.info("Maximum positions reached (%s).", MAX_POSITIONS)
                time.sleep(POLL_SECONDS)
                continue

            for symbol in SYMBOLS:
                symbol = symbol.strip().upper()
                if not symbol or symbol in held or len(held) >= MAX_POSITIONS:
                    continue

                signal = find_signal(symbol)
                if not signal:
                    continue

                equity = float(account.equity)
                risk_budget = equity * RISK_FRACTION
                per_share_risk = signal["entry_reference"] - signal["stop"]
                qty = int(risk_budget / per_share_risk)
                if qty < 1:
                    logging.info("%s: position size below one share; skip", symbol)
                    continue

                logging.info(
                    "PAPER SIGNAL %s qty=%s ref=%.2f stop=%.2f target=%.2f",
                    symbol, qty, signal["entry_reference"],
                    signal["stop"], signal["target"]
                )

                if not ENABLE_ORDERS:
                    logging.info("Orders disabled. Set ENABLE_PAPER_ORDERS=true only after review.")
                    continue

                order = MarketOrderRequest(
                    symbol=symbol,
                    qty=qty,
                    side=OrderSide.BUY,
                    time_in_force=TimeInForce.DAY,
                    order_class=OrderClass.BRACKET,
                    take_profit=TakeProfitRequest(limit_price=round(signal["target"], 2)),
                    stop_loss=StopLossRequest(stop_price=round(signal["stop"], 2)),
                )
                trading.submit_order(order)
                held.add(symbol)
                logging.info("%s: paper bracket order submitted.", symbol)

        except Exception:
            logging.exception("Bot cycle failed; no assumptions made.")
        time.sleep(POLL_SECONDS)

if __name__ == "__main__":
    main()
